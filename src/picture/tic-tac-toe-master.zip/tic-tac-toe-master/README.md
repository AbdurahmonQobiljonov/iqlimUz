# Tic Tac Toe
## Using only HTML + CSS + JS

<img src="game.png" alt="game" style="margin-left: 15px;" />
